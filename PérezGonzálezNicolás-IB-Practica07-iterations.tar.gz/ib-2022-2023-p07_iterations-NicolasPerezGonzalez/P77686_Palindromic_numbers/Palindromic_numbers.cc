/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Nicolás Pérez González alu0101558219@ull.edu.es
  * @date Nov 14 2022
  * @brief A function that tells whether the natural number n is a palindromic number or not.
  * @bug There are no known bugs
  * @see 

  C++     bool is_palindromic(int n);
  C       int is_palindromic(int n);
  Java    public static boolean isPalindromic(int n);
  Python  is_palindromic(n)  # returns bool
 	        is_palindromic(n: int) -> bool
  */
#include <iostream>

int Palindromic() {
   
