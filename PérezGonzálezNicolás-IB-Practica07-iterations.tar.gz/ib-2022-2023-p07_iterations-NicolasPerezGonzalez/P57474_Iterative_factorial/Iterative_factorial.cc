/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Nicolás Pérez González alu0101558219@ull.edu.es
  * @date Nov 14 2022
  * @brief An iterative function that, given a natural n, returns its factorial n!.
  * @bug There are no known bugs
  * @see https://jutge.org/problems/P57474_en
  */

/**
  C++	     int factorial(int n);
  C        int factorial(int n);
  Java     public static int factorial(int n);
  Python	 factorial(n)  # returns int
 	         factorial(n: int) -> int
*/

