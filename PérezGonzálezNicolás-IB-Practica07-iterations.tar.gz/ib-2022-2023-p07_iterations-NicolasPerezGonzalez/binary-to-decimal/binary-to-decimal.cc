/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Nicolás Pérez González alu0101558219@ull.edu.es
  * @date Nov 11 2022
  * @brief Programa que convierte números binarios a decimales
  * @bug There are no known bugs
  * @see 
  */

#include <iostream>
#include <cmath>

int main() {

  int binary;
  int numb{0};
  int counter{0};

  std::cin >> binary;

  while (binary != 0) {
    if (((binary % 10) != 0) && ((binary % 10) != 1)) {
      std::cout << "Wrong Input" << std::endl;

      return 0;
    } else {
      numb = (numb + ((binary % 10) * pow(2, counter)));

      binary = (binary / 10);

      counter++;
    }
  }

  std::cout << numb << std::endl;

  return 0;
}
