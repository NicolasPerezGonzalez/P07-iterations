/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica 2022-2023
 *
 * @author Nicolás Pérez González alu0101558219@ull.edu.es
 * @date Nov 11 2022
 * @brief Programa que lee un número natural e imprime como salida la suma de los dígitos del número en cuestión.
 * @bug There are no known bugs
 * @see 
 */

#include <iostream>

int main () {

  int va1;
  int suma{0};

  std::cin >> va1;
  
  while (va1 != 0) {
    suma = (suma + (va1%10));

    va1 = (va1 / 10);
  }

  std::cout << suma << std::endl;

  return 0;

}
  
