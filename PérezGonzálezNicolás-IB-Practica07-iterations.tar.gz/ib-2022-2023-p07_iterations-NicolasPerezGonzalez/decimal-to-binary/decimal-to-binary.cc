/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Nicolás Pérez González alu0101558219@ull.edu.es
  * @date Nov 11 2022
  * @brief Programa que convierte de decimal a binario 
  * @bug There are no known bugs
  * @see 
  */

#include <iostream>

int main () {

  int numb;

  std::cin >> numb;

  while (numb != 0) {
    std::cout << numb % 2;
    
    numb = (numb / 2);
  }

  std::cout << std::endl;

  return 0;
}
