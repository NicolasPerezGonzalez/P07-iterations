/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Nicolás Pérez González alu0101558219@ull.edu.es
  * @date Nov 11 2022
  * @brief Programa que imprima una cantidad de números de la serie de Fibonacci
  * @bug There are no known bugs
  * @see 
  */


#include <iostream>

int main() {
  
  int first{0};
  int second{1};
  int aux;
  int va1;

  std::cin >> va1;
  
  std::cout << first;

  for (int i{0}; i<va1; i++) {
    std::cout << " " << second;

    aux = first;
    first = second;
    second = (aux + second);
  }

  std::cout << std::endl;

  return 0;

}
