/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Nicolás Pérez González alu0101558219@ull.edu.es
  * @date Nov 11 2022
  * @brief Programa que indique si un año es bisiesto o no
  * @bug There are no known bugs
  * @see 
  */

#include <iostream>

bool TwoCeros(int numb) {
  if (((numb % 10) == 0) && ((numb % 100) == 0)) {
    return 1;
  }

  return 0;
}


bool MultipleOfFour(int numb) {
  if ((numb % 4) == 0) { return 1;}

  return 0;
}


int main() {

  int year;
  
  std::cin >> year;

  if (MultipleOfFour(year) && !TwoCeros(year)) {
    std::cout << "YES" << std::endl;

  } else if (TwoCeros(year) && MultipleOfFour(year / 100)) {
    std::cout << "YES" << std::endl;
  
  } else {
    std::cout << "NO" << std::endl;
  }

  return 0;
}
